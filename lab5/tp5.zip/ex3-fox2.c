#include <stdlib.h>
#include <time.h>
#include <stdio.h>
#include <mpi.h>
#include <unistd.h>
#include <math.h>

#define ndims 2

void printMat(int *mat, int size){
        int dim = sqrt(size);
        for (int i = 0; i < size; i++) {
                if (i%dim==0 && i!=0) {
                        printf("\n%d ", *(mat+i));
                } else {
                        printf("%d ", *(mat+i));
                }
        }
        printf("\n---------\n");
}

// Fox Algorithm Matrix Multiplication with data distribution
int main(int argc, char *argv[]){
        int rank_topology, rank_col_comm, rank_row_comm, size;
        int reorder = 0;
        int dims[ndims] = {0}, periods[ndims] = {1,1}, coords[ndims] = {0}, maxdims = ndims, remainsRow[ndims]={0,1}, remainsCol[ndims]={1,0};
        int nnodes, dim;
        int a, b, c = 0;
        MPI_Comm topologyComm, rowComm, colComm; //subComm for broadcast A and shifting B
        MPI_Status status;
        MPI_Datatype typeMatRow, typeMatCol;



        MPI_Init(&argc,&argv);
        MPI_Comm_rank(MPI_COMM_WORLD, &rank_topology);
        MPI_Comm_size(MPI_COMM_WORLD, &size);

        //Init value of matrix at rank 0
        dim = floor(sqrt(size));
        nnodes = dim*dim;

        int matA[nnodes], matB[nnodes], matC[nnodes], sendCount[nnodes], displacesRow[nnodes], displacesCol[nnodes];

        for (int i = 0; i < nnodes; i++) {
                matA[i] = i;
                matB[i] = i;
                matC[i] = i;
                sendCount[i] = 1;
        }

        for (int i = 0; i < nnodes; i++) {
                displacesRow[i] = i/dim;
                displacesCol[i] = i%dim;
        }

        // if(rank_topology == 0 && 0 == 0) {
        //         printMat(sendCount,nnodes);
        //         printf("------\n");
        //         printMat(displacesRow,nnodes);
        //         printf("------\n");
        //         printMat(displacesCol,nnodes);
        // }

        for (int i = 0; i < ndims; i++) {
                dims[i] = dim;
        }

        MPI_Type_vector(dim, 1, 1, MPI_INT, &typeMatRow);
        MPI_Type_vector(dim, 1, dim, MPI_INT, &typeMatCol);
        MPI_Type_commit(&typeMatRow);
        MPI_Type_commit(&typeMatCol);

        MPI_Dims_create(nnodes, ndims, dims);
        MPI_Cart_create(MPI_COMM_WORLD, ndims, dims, periods, reorder, &topologyComm);

        if (rank_topology < nnodes) {
                MPI_Cart_sub(topologyComm, remainsRow, &rowComm);
                MPI_Cart_sub(topologyComm, remainsCol, &colComm);
                MPI_Cart_coords(topologyComm, rank_topology, maxdims, coords);
                // printf("Rank %d has coordinates (%d,%d) holds value A=%d, B=%d in topologyComm\n", rank_topology, coords[0], coords[1],a,b);

                int a_temp, root, src, dest, b_temp = b;
                MPI_Comm_rank(rowComm, &rank_row_comm);

                // Data distribution
                // MPI_Scatterv(void *sendbuf,int *sendcnts,int *displs,MPI_Datatype sendtype,void *recvbuf,int recvcnt,MPI_Datatype recvtype,int root,MPI_Comm comm);
                MPI_Scatterv(matA, sendCount, displacesRow, typeMatRow, matA, 1, typeMatRow, 0, topologyComm);
                MPI_Scatterv(matB, sendCount, displacesCol, typeMatCol, matB, 1, typeMatRow, 0, topologyComm);

                if (rank_topology != 0) {
                        printf("Rank%d: ", rank_topology);
                        printMat(matB, nnodes);
                        printMat(matA, nnodes);
                        sleep(rank_topology+2);
                }
                return 0;

                // Loop for n stages
                for (int stage = 0; stage < dim; stage++) {
                        a_temp = a;
                        b_temp = b;

                        // Broadcasting A
                        root = (coords[0] + stage) % dim;
                        MPI_Bcast(&a_temp, 1, MPI_INT, root, rowComm);

                        // Local Computation
                        c = c + (a_temp * b_temp);

                        // Shifting B
                        MPI_Cart_shift(colComm, 0, -1, &src, &dest);
                        MPI_Sendrecv(&b_temp, 1, MPI_INT,dest, 95, &b, 1, MPI_INT, src, 95, colComm,&status);
                        MPI_Barrier(colComm);

                        //printf("\tStage %d Rank %d Root %d: A=%d B=%d\n", stage, rank_topology, root, a_temp, b_temp);
                }
                printf("Rank %d has c = %d\n", rank_topology,c);
        } else {
                printf("\n");
        }


        MPI_Finalize();
        return 0;
}
